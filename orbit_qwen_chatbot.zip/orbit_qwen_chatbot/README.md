# orBIT Chatbot with Qwen Fallback

A conversational chatbot for marketing college programs using NLP techniques and Qwen fallback.

## Setup Instructions

1. Install dependencies:
   ```bash
   pip install -r requirements.txt